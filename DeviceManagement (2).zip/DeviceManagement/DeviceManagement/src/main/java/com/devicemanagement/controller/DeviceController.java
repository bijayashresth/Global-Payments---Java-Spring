package com.devicemanagement.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.devicemanagement.bean.Device;
import com.devicemanagement.bean.ErrorResponse;
import com.devicemanagement.bean.Response;
import com.devicemanagement.serviceimpl.DeviceServiceImpl;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Validated
@Api(tags = "Device APIs")
@RestController
@RequestMapping(value = "/device")
public class DeviceController {

	@Autowired
	private DeviceServiceImpl deviceService;

	@PostMapping(value = "/addDevice")
	@ApiOperation(value = "Create Device details ", notes = "Create Devices.")
	public ResponseEntity<Response> createDevice(@Valid @RequestBody Device device) {
		ErrorResponse errorResponse = validateDevice(device);
		if (errorResponse != null) {
			return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
		}
		Device response = deviceService.createDevice(device);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@PutMapping(value = "/updateDevice")
	@ApiOperation(value = "Update Device details ", notes = "Update Device details.")
	public ResponseEntity<Response> updateDevice(@RequestBody @Valid Device device) {
		Response response = new Response();
		response = validateDevice(device);
		if (response != null) {
			return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		}
		response = deviceService.updateDevice(device);
		
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@GetMapping(value = "/allDevices")
	@ApiOperation(value = "Get all Devices", notes = "Get all Devices.")
	public ResponseEntity<List<Device>> getAllDevices() {
		List<Device> response =  deviceService.getAll();
		return new ResponseEntity<>(response, HttpStatus.OK);
	} 
	
	@GetMapping(value = "/searchDevice")
	@ApiOperation(value = "Search for Device", notes = "Search for Device basesd on Serial number and Machine code.")
	public ResponseEntity<Response> searchDevice(@RequestParam String serialNumber, @RequestParam String machineCode) {
		Response response =  deviceService.getDeviceBySerialNoAndMachineCode(serialNumber, machineCode);
		if(response.getClass().isInstance(Device.class)) {
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
	}

	private ErrorResponse validateDevice(@Valid Device device) {

		if (!device.validate()) {
			ErrorResponse response = new ErrorResponse("serial.number.invalid", "ER003",
					"The serial number entered can include a - z, A - Z, 0 - 9 and hyphen. Please correct your entry");
			return response;
		} else if (device.getMachineCode() == null || "".equals(device.getMachineCode())) {
			ErrorResponse response = new ErrorResponse("machine.code.invalid", "ER001",
					"The machine code is incorrect. Check the Machine code you provided and try again");
			return response;
		}
		return null;
	}
}