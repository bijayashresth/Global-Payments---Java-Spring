package com.devicemanagement.repository;

import java.util.List;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.devicemanagement.bean.Device;

@Repository
public interface DeviceRepository extends JpaRepository<Device, Integer>{
	
	public List<Device> findBySerialNumberAndMachineCode(@Param("serialNumber") String serialNumber,@Param("machineCode") String machineCode);	
	public List<Device> findBySerialNumber(@Param("serialNumber") String serialNumber);	
	public List<Device> findByMachineCode(@Param("machineCode") String machineCode);	
}


