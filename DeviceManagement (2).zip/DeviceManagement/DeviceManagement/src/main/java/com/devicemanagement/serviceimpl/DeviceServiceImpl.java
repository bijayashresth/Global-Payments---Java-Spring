package com.devicemanagement.serviceimpl;

import java.util.List;
import java.util.Optional;
import javax.validation.Valid;
import javax.validation.constraints.Min;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.yaml.snakeyaml.util.ArrayUtils;

import com.devicemanagement.bean.Device;
import com.devicemanagement.bean.ErrorResponse;
import com.devicemanagement.bean.Response;
import com.devicemanagement.repository.DeviceRepository;

@Component
public class DeviceServiceImpl{

	@Autowired
	private DeviceRepository deviceRepository;
	
	public Device createDevice(Device device) {
		return deviceRepository.save(device);
	}

	public Response updateDevice(Device device) {
		List<Device> existingDevice = deviceRepository.findBySerialNumber(device.getSerialNumber());
		if(CollectionUtils.isEmpty(existingDevice)) {
			ErrorResponse response = new ErrorResponse("serial.number.not.found", "ER004",
					"The serial number does not match our records.");
			return response;
		}
		existingDevice = deviceRepository.findByMachineCode(device.getMachineCode());
		if(CollectionUtils.isEmpty(existingDevice)) {
			ErrorResponse response = new ErrorResponse("machine.code.invalid", "ER001",
					"The machine code is incorrect. Check the Machine code you provided and try again.");
			return response;
		}
		
		return deviceRepository.save(device);
	}
	public Response getDeviceBySerialNoAndMachineCode(String serialNumber, String machineCode) {
		List<Device> existingDevice = deviceRepository.findBySerialNumber(serialNumber);
		if(CollectionUtils.isEmpty(existingDevice)) {
			ErrorResponse response = new ErrorResponse("serial.number.not.found", "ER004",
					"The serial number does not match our records.");
			return response;
		}
		existingDevice = deviceRepository.findByMachineCode(machineCode);
		if(CollectionUtils.isEmpty(existingDevice)) {
			ErrorResponse response = new ErrorResponse("machine.code.invalid", "ER001",
					"The machine code is incorrect. Check the Machine code you provided and try again.");
			return response;
		}
		return deviceRepository.findBySerialNumberAndMachineCode(serialNumber, machineCode).get(0);
	}

	public List<Device> getAll(){
		return deviceRepository.findAll();
	}

}