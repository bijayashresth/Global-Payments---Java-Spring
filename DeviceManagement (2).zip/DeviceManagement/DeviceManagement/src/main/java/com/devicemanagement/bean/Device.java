package com.devicemanagement.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.regex.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Device extends Response {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	@ApiModelProperty(required = true)
	private String serialNumber;
	@ApiModelProperty(required = true)
	private String machineCode;
	@ApiModelProperty(required = true)
	private String deviceName;

	public boolean validate() {
		Pattern p = Pattern.compile("[a-zA-Z0-9]*-[a-zA-Z0-9]*");
		Matcher m = p.matcher(this.serialNumber);
		return m.matches();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getMachineCode() {
		return machineCode;
	}

	public void setMachineCode(String machineCode) {
		this.machineCode = machineCode;
	}

	public String getDeviceName() {
		return deviceName;
	}

	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	
}