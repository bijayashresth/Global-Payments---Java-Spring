package com.devicemanagement.bean;

public class Response {

}
